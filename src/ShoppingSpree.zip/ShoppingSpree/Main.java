package ShoppingSpree;

public class Main {
    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        Map<String, Person> peopleMap = new LinkedHashMap<>();
//        String[] people = scanner.nextLine().split(";");
//        String[] products = scanner.nextLine().split(";");
//        for (String person : people) {
//            String[] tokens = person.split("=");
//            String name = tokens[0];
//            double money = Double.parseDouble(tokens[1]);
//            Person currentPerson = new Person(name,money);
//            peopleMap.putIfAbsent(name, currentPerson);
//        }
//        Map<String,Product> productList = new HashMap<>();
//
//        for (String product : products) {
//            String[] tokens = product.split("=");
//            String name = tokens[0];
//            double cost = Double.parseDouble(tokens[1]);
//            Product currentProduct = new Product(name,cost);
//            productList.putIfAbsent(name,currentProduct);
//
//        }
//        String command = scanner.nextLine();
//        while (!command.equals("END")){
//            String[] tokens = command.split("\\s+");
//            String name = tokens[0];
//            String product = tokens[1];
//            try {
//                peopleMap.get(name).buyProduct(productList.get(product));
//            } catch (RuntimeException e) {
//                System.out.print(e.getMessage());
//            }
//            command = scanner.nextLine();
//        }
//        for (Map.Entry<String, Person> person : peopleMap.entrySet()) {
//            System.out.println(person.getValue());
//        }
    }
}
