//package WorkingWithAbstraction.Exercise.CardSuit;

import java.util.Scanner;

public enum CardSuit {
    CLUBS, DIAMONDS, HEARTS, SPADES;



}
