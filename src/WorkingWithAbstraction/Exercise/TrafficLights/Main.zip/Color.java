//package WorkingWithAbstraction.Exercise.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;
}
