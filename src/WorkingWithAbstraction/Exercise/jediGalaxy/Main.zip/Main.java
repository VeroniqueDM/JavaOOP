//package WorkingWithAbstraction.Exercise.jediGalaxy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] dimestions = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        int rows = dimestions[0];
        int cols = dimestions[1];

        int[][] matrix = new int[rows][cols];

        fillMatrix(rows, cols, matrix);

        String command = scanner.nextLine();
        long sum = 0;
        while (!command.equals("Let the Force be with you")) {
            int[] ivoS = Arrays.stream(command.split(" ")).mapToInt(Integer::parseInt).toArray();
            int[] evil = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
            int xE = evil[0];
            int yE = evil[1];

            evilPath(matrix, xE, yE);

            int xI = ivoS[0];
            int yI = ivoS[1];

            sum = getSum(matrix, sum, xI, yI);

            command = scanner.nextLine();
        }
        System.out.println(sum);
    }

    private static void evilPath(int[][] matrix, int xE, int yE) {
        while (xE >= 0 && yE >= 0) {
            if (xE < matrix.length && yE < matrix[0].length) {
                matrix[xE][yE] = 0;
            }
            xE--;
            yE--;
        }
    }

    private static long getSum(int[][] matrix, long sum, int xI, int yI) {
        while (xI >= 0 && yI < matrix[1].length) {
            if (xI < matrix.length && yI >= 0 && yI < matrix[0].length) {
                sum += matrix[xI][yI];
            }
            yI++;
            xI--;
        }
        return sum;
    }
    private static void fillMatrix(int rows, int cols, int[][] matrix) {
        int value = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = value++;
            }
        }
    }
}
