package ReflectionAndAnnotation.Exercise.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
