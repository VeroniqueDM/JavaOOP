package ReflectionAndAnnotation.Exercise.barracksWars.interfaces;

public interface Runnable {
	void run();
}
