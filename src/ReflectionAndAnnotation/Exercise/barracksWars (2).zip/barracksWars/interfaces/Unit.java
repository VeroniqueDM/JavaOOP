package ReflectionAndAnnotation.Exercise.barracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
