package robotService.entities.supplements;

public class PlasticArmor extends BaseSupplement{
    private static final int DEFAULT_HARDNESS = 1;
    private static final double DEFAULT_PRICE = 10.0;
    public PlasticArmor() {
        super(DEFAULT_HARDNESS, DEFAULT_PRICE);
    }
}
